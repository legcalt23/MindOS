// Fase F mutation harness. Applies ONE mutant at a time, always starting from the pristine bytes
// (mutants never stack). CRLF/UTF-8 safe: exact-substring replace, asserts exactly one occurrence.
// Never uses sed. Usage: node mutate.mjs list | node mutate.mjs apply <id>
import { readFileSync, writeFileSync } from 'node:fs'

const ELIG = 'shared/src/commonMain/kotlin/com/mindos/app/features/mindboost/focus2/domain/evidence/FocusTemporalEligibility.kt'
const POL = 'shared/src/commonMain/kotlin/com/mindos/app/features/mindboost/focus2/domain/evidence/FocusEvidenceStatePolicy.kt'
const PRISTINE = {
  [ELIG]: '.mutation-pristine/FocusTemporalEligibility.kt',
  [POL]: '.mutation-pristine/FocusEvidenceStatePolicy.kt',
}

// find strings are exact substrings of the pristine bytes; the one 2-line mutant carries an explicit \r\n.
const MUTANTS = [
  { id: 'M1_backstop_gt_to_ge', file: ELIG, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: '?: FULLY_EXCLUDED) > thresholds.sessionExcludedMax', repl: '?: FULLY_EXCLUDED) >= thresholds.sessionExcludedMax' },
  { id: 'M2_backstop_gt_to_lt', file: ELIG, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: '?: FULLY_EXCLUDED) > thresholds.sessionExcludedMax', repl: '?: FULLY_EXCLUDED) < thresholds.sessionExcludedMax' },
  { id: 'M3_always_eligible', file: ELIG, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: 'if (causes.isEmpty()) Verdict.Eligible else Verdict.Excluded(causes)', repl: 'Verdict.Eligible' },
  { id: 'M4_always_excluded', file: ELIG, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: 'if (causes.isEmpty()) Verdict.Eligible else Verdict.Excluded(causes)', repl: 'Verdict.Excluded(causes)' },
  { id: 'M5_fraction_always_zero', file: ELIG, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: 'if (denominator > 0) (excludedResolved + discards).toDouble() / denominator else null',
    repl: 'if (denominator > 0) 0.0 else null' },
  { id: 'M6_accepted_not_excluded_fraction', file: ELIG, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: 'if (denominator > 0) (excludedResolved + discards).toDouble() / denominator else null',
    repl: 'if (denominator > 0) 1.0 - (excludedResolved + discards).toDouble() / denominator else null' },
  { id: 'M7_threshold_hardcoded_050', file: ELIG, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: '?: FULLY_EXCLUDED) > thresholds.sessionExcludedMax', repl: '?: FULLY_EXCLUDED) > 0.50' },
  { id: 'M8_threshold_hardcoded_099_ignores_injected', file: ELIG, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: '?: FULLY_EXCLUDED) > thresholds.sessionExcludedMax', repl: '?: FULLY_EXCLUDED) > 0.99' },
  { id: 'M9_omit_nonauth_cause', file: ELIG, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: 'if (sessionClass != TemporalClass.T1_FRAME_OBSERVED) add(ExclusionCause.NON_AUTHORITATIVE_CLASS)',
    repl: 'if (false) add(ExclusionCause.NON_AUTHORITATIVE_CLASS)' },
  { id: 'M10_omit_coverage_cause', file: ELIG, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: 'if (!coverageComplete) add(ExclusionCause.COVERAGE_INCOMPLETE)',
    repl: 'if (false) add(ExclusionCause.COVERAGE_INCOMPLETE)' },
  { id: 'M11_omit_backstop_cause', file: ELIG, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: 'if ((excludedFraction ?: FULLY_EXCLUDED) > thresholds.sessionExcludedMax) {', repl: 'if (false) {' },
  { id: 'M12_reorder_causes_EQUIVALENT', file: ELIG, killer: '*AdversarialOracleTest', expect: 'SURVIVE',
    find: 'if (sessionClass != TemporalClass.T1_FRAME_OBSERVED) add(ExclusionCause.NON_AUTHORITATIVE_CLASS)\n            if (!coverageComplete) add(ExclusionCause.COVERAGE_INCOMPLETE)',
    repl: 'if (!coverageComplete) add(ExclusionCause.COVERAGE_INCOMPLETE)\n            if (sessionClass != TemporalClass.T1_FRAME_OBSERVED) add(ExclusionCause.NON_AUTHORITATIVE_CLASS)' },
  { id: 'M13_rtShadow_ignores_temporal_verdict', file: POL, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: 'temporal?.rtShadowVerdict == FocusTemporalEligibility.Verdict.Eligible', repl: 'true' },
  { id: 'M14_allow_official_eligible', file: POL, killer: '*AdversarialOracleTest', expect: 'KILL',
    find: 'else -> FocusEvidenceState.PROVISIONAL', repl: 'else -> FocusEvidenceState.OFFICIAL_ELIGIBLE' },
]

const mode = process.argv[2]
if (mode === 'list') {
  process.stdout.write(MUTANTS.map((m) => `${m.id}|${m.file}|${m.killer}|${m.expect}`).join('\n') + '\n')
  process.exit(0)
}
if (mode === 'apply') {
  const m = MUTANTS.find((x) => x.id === process.argv[3])
  if (!m) { process.stderr.write(`UNKNOWN_MUTANT ${process.argv[3]}\n`); process.exit(2) }
  const src = readFileSync(PRISTINE[m.file], 'utf8')
  const occ = src.split(m.find).length - 1
  if (occ !== 1) { process.stderr.write(`ANCHOR_COUNT=${occ} (expected 1) for ${m.id}\n`); process.exit(3) }
  writeFileSync(m.file, src.replace(m.find, m.repl))
  process.stdout.write(`APPLIED ${m.id} expect=${m.expect} killer=${m.killer}\n`)
  process.exit(0)
}
process.stderr.write('usage: node mutate.mjs list | apply <id>\n'); process.exit(1)
