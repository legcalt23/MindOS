#!/usr/bin/env bash
# Fase F (M12 survivor XML + M15 barrier) + Fase J regressions. Serial only. Worktree production is
# always left pristine (byte-identical verify after every mutation).
set -uo pipefail
cd "$(dirname "$0")/.." || exit 1
ELIG=shared/src/commonMain/kotlin/com/mindos/app/features/mindboost/focus2/domain/evidence/FocusTemporalEligibility.kt
POL=shared/src/commonMain/kotlin/com/mindos/app/features/mindboost/focus2/domain/evidence/FocusEvidenceStatePolicy.kt
PRIS_E=.mutation-pristine/FocusTemporalEligibility.kt
PRIS_P=.mutation-pristine/FocusEvidenceStatePolicy.kt
SHA_E=$(sha256sum "$PRIS_E" | cut -d' ' -f1)
XD=shared/build/test-results/desktopTest
ORACLE_XML="$XD/TEST-com.mindos.app.features.mindboost.focus2.simulation.FocusTemporalEligibilityAdversarialOracleTest.xml"
BOUNDARY_XML="$XD/TEST-com.mindos.app.features.mindboost.focus2.Focus2DependencyBoundaryTest.xml"
G() { ./gradlew "$@" --project-cache-dir .gpc --offline --console=plain; }
verify_elig() { [ "$(sha256sum "$ELIG" | cut -d' ' -f1)" = "$SHA_E" ] && echo IDENTICAL || echo DRIFT; }
suite_totals() { # $1 = xml file
  grep -o '<testsuite[^>]*>' "$1" | head -1 | grep -oE '(tests|failures|errors|skipped)="[0-9]*"' | tr '\n' ' '
}

echo "FINAL_GATES_START $(date -u +%FT%TZ)"

echo "== STEP A: M12 survivor re-run WITH XML capture (must be 15 tests / 0 failures) =="
node .mutation-pristine/mutate.mjs apply M12_reorder_causes_EQUIVALENT
rm -f "$ORACLE_XML"
G :shared:desktopTest --tests '*AdversarialOracleTest' > .mutation-pristine/gate_M12rerun.log 2>&1
echo "  M12 exit=$?"
[ -f "$ORACLE_XML" ] && echo "  M12 oracle XML: $(suite_totals "$ORACLE_XML")" || echo "  M12 oracle XML: ABSENT"
cp "$PRIS_E" "$ELIG"; echo "  restore elig: $(verify_elig)"

echo "== STEP B: M15 barrier mutant — inject a profile ref, boundary test MUST go RED, then GREEN on restore =="
node -e '
const fs=require("fs");const f=process.argv[1];const s=fs.readFileSync(f,"utf8");
const anchor="    private const val FULLY_EXCLUDED: Double = 1.0";
if((s.split(anchor).length-1)!==1){console.error("ANCHOR!=1");process.exit(3);}
const inj=anchor+"\n\n    @Suppress(\"unused\", \"UnusedPrivateMember\")\n    private fun mutantM15BarrierProbe(c: com.mindos.app.features.mindboost.profile.domain.model.ModuleContribution?): Int? = c?.hashCode()";
fs.writeFileSync(f,s.replace(anchor,inj));console.log("M15 injected");
' "$ELIG"
rm -f "$BOUNDARY_XML"
G :shared:desktopTest --tests '*Focus2DependencyBoundaryTest' > .mutation-pristine/gate_M15_dirty.log 2>&1
M15_DIRTY=$?
echo "  M15 dirty exit=$M15_DIRTY (expect != 0 = barrier caught it)"
grep -E 'no_focus2_class_reaches_the_profile|FAILED|tests completed' .mutation-pristine/gate_M15_dirty.log | head -4
cp "$PRIS_E" "$ELIG"; echo "  restore elig: $(verify_elig)"
rm -f "$BOUNDARY_XML"
G :shared:desktopTest --tests '*Focus2DependencyBoundaryTest' > .mutation-pristine/gate_M15_clean.log 2>&1
M15_CLEAN=$?
echo "  M15 clean exit=$M15_CLEAN (expect 0 = barrier passes on pristine)"
[ -f "$BOUNDARY_XML" ] && echo "  boundary XML: $(suite_totals "$BOUNDARY_XML")" || echo "  boundary XML: ABSENT"

echo "== STEP C: FULL :shared:desktopTest on PRISTINE (Fase J, --rerun-tasks for real execution) =="
echo "  pre-run elig: $(verify_elig)"
G :shared:desktopTest --rerun-tasks > .mutation-pristine/gate_full_desktopTest.log 2>&1
FULL=$?
echo "  full desktopTest exit=$FULL"
node -e '
const fs=require("fs"),p=require("path");const d="shared/build/test-results/desktopTest";
let T=0,F=0,E=0,S=0,focusT=0,focusF=0,cls=0,fcls=0;
for(const f of fs.readdirSync(d)){if(!/^TEST-.*\.xml$/.test(f))continue;
  const x=fs.readFileSync(p.join(d,f),"utf8");const m=x.match(/<testsuite\b[^>]*\btests="(\d+)"[^>]*\bskipped="(\d+)"[^>]*\bfailures="(\d+)"[^>]*\berrors="(\d+)"/);
  if(!m)continue;cls++;T+=+m[1];S+=+m[2];F+=+m[3];E+=+m[4];
  if(f.includes(".focus2.")){fcls++;focusT+=+m[1];focusF+=+m[3]+ +m[4];}}
console.log("  FULL desktopTest: classes="+cls+" tests="+T+" failures="+F+" errors="+E+" skipped="+S);
console.log("  focus2 subset:    classes="+fcls+" tests="+focusT+" failures+errors="+focusF);
'

echo "== STEP D: :shared:detekt (module-wide) =="
G :shared:detekt > .mutation-pristine/gate_detekt.log 2>&1
DETEKT=$?
echo "  detekt exit=$DETEKT"
DXML=shared/build/reports/detekt/detekt.xml
if [ -f "$DXML" ]; then
  echo "  total detekt findings: $(grep -c '<error ' "$DXML")"
  echo "  --- findings touching MY new files (must be 0) ---"
  grep -E 'FocusTemporalEligibilityProperty\.kt|FocusTemporalEligibilityAdversarialOracleTest\.kt' "$DXML" | sed 's#<REPO_USER>/]*#<REPO>#g' || echo "  (none — my files are clean)"
  echo "  --- distinct files with findings ---"
  grep -oE 'name="[^"]*\.kt"' "$DXML" | sed 's/name="//; s/"$//' | xargs -n1 basename 2>/dev/null | sort -u | head -20
else
  echo "  detekt XML absent; tail log:"; tail -15 .mutation-pristine/gate_detekt.log | sed 's#<REPO_USER>/]*#<REPO>#g'
fi

echo "== FINAL PRISTINE VERIFY =="
echo "  elig: $(verify_elig)  pol: $([ "$(sha256sum "$POL"|cut -d' ' -f1)" = "$(sha256sum "$PRIS_P"|cut -d' ' -f1)" ] && echo IDENTICAL || echo DRIFT)"
echo "FINAL_GATES_END $(date -u +%FT%TZ)  [M12_XML | M15_dirty=$M15_DIRTY M15_clean=$M15_CLEAN | full=$FULL detekt=$DETEKT]"
