# S5 · Paso 4 evidence bundle (IMPLEMENTED_BUT_NOT_CLOSED)
Sanitized (host/user redacted). Verify from this directory:
  node ../../.../parse-junit-xml.mjs xml          # focus2 total DERIVED from the primary XML (28 suites)
  node -e 'require("fs").readFileSync("mutation_report.jsonl","utf8")'   # 14-mutant campaign verdicts
TRANSFER_MANIFEST.json lists every member with size + SHA-256; recompute and compare.
Mutation: 15 mutants (14 in mutation_report.jsonl + M15 barrier in logs/gate_M15_*.log) -> 14 KILL + 1 SURVIVE
(M12 equivalent). Full desktop suite 570 classes / 4032 tests / 0F / 0E / 0S (logs/final_gates_console.log).
Both SUTs (src/FocusTemporalEligibility.kt, src/FocusEvidenceStatePolicy.kt) are UNCHANGED production bytes.
