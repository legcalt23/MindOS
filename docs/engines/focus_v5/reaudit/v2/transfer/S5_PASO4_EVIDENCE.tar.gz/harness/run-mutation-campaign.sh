#!/usr/bin/env bash
# Fase F — real, isolated, reversible mutation campaign against the two SUTs.
# For each mutant: apply (from pristine) -> run the killing test -> record kill/survive from the REAL
# exit code + XML failures -> restore byte-identical -> verify sha256 == pristine. Serial only.
set -uo pipefail
cd "$(dirname "$0")/.." || exit 1   # worktree root
REPORT=.mutation-pristine/mutation_report.jsonl
: > "$REPORT"
ELIG=shared/src/commonMain/kotlin/com/mindos/app/features/mindboost/focus2/domain/evidence/FocusTemporalEligibility.kt
POL=shared/src/commonMain/kotlin/com/mindos/app/features/mindboost/focus2/domain/evidence/FocusEvidenceStatePolicy.kt
PRIS_E=.mutation-pristine/FocusTemporalEligibility.kt
PRIS_P=.mutation-pristine/FocusEvidenceStatePolicy.kt
SHA_E=$(sha256sum "$PRIS_E" | cut -d' ' -f1)
SHA_P=$(sha256sum "$PRIS_P" | cut -d' ' -f1)
XML=build/test-results/desktopTest/TEST-com.mindos.app.features.mindboost.focus2.simulation.FocusTemporalEligibilityAdversarialOracleTest.xml

restore_and_verify() {
  cp "$PRIS_E" "$ELIG"; cp "$PRIS_P" "$POL"
  local ne np ok=1
  ne=$(sha256sum "$ELIG" | cut -d' ' -f1); np=$(sha256sum "$POL" | cut -d' ' -f1)
  [ "$ne" = "$SHA_E" ] || ok=0
  [ "$np" = "$SHA_P" ] || ok=0
  echo "$ok"
}

echo "CAMPAIGN_START $(date -u +%FT%TZ)"
for id in $(node .mutation-pristine/mutate.mjs list | cut -d'|' -f1); do
  expect=$(node .mutation-pristine/mutate.mjs list | grep "^$id|" | cut -d'|' -f4)
  killer=$(node .mutation-pristine/mutate.mjs list | grep "^$id|" | cut -d'|' -f3)
  # apply from pristine
  applyout=$(node .mutation-pristine/mutate.mjs apply "$id" 2>&1)
  if ! echo "$applyout" | grep -q '^APPLIED'; then
    echo "{\"id\":\"$id\",\"error\":\"apply_failed\",\"detail\":\"$applyout\"}" >> "$REPORT"
    restore_and_verify >/dev/null; continue
  fi
  rm -f "$XML"
  ./gradlew :shared:desktopTest --tests "$killer" --project-cache-dir .gpc --offline --console=plain \
    > .mutation-pristine/run_"$id".log 2>&1
  exit=$?
  failures=""; failnames=""
  if [ -f "$XML" ]; then
    failures=$(grep -o 'failures="[0-9]*"' "$XML" | head -1 | grep -o '[0-9]*')
    failnames=$(grep -o 'testcase name="[^"]*"' "$XML" | sed 's/testcase name="//' | tr '\n' ';' | head -c 400)
  fi
  # killed iff the build did not succeed (test failure OR compile-catch)
  if [ "$exit" -ne 0 ]; then verdict=KILL; else verdict=SURVIVE; fi
  [ "$verdict" = "$expect" ] && status=OK || status=UNEXPECTED
  restored=$(restore_and_verify)
  echo "{\"id\":\"$id\",\"expect\":\"$expect\",\"verdict\":\"$verdict\",\"status\":\"$status\",\"gradle_exit\":$exit,\"xml_failures\":\"${failures:-NA}\",\"restored_byte_identical\":$restored,\"killer\":\"$killer\"}" >> "$REPORT"
  echo "  $id -> $verdict (expect $expect) status=$status exit=$exit failures=${failures:-NA} restored=$restored"
done
echo "CAMPAIGN_END $(date -u +%FT%TZ)"
echo "=== FINAL PRISTINE VERIFY ==="
echo "elig $([ "$(sha256sum "$ELIG" | cut -d' ' -f1)" = "$SHA_E" ] && echo IDENTICAL || echo DRIFT)"
echo "pol  $([ "$(sha256sum "$POL" | cut -d' ' -f1)" = "$SHA_P" ] && echo IDENTICAL || echo DRIFT)"
echo "=== SUMMARY ==="
node -e 'const fs=require("fs");const rows=fs.readFileSync(".mutation-pristine/mutation_report.jsonl","utf8").trim().split("\n").map(JSON.parse);const ok=rows.filter(r=>r.status==="OK").length;const unexpected=rows.filter(r=>r.status==="UNEXPECTED");const kills=rows.filter(r=>r.verdict==="KILL").length;const surv=rows.filter(r=>r.verdict==="SURVIVE").length;const badrestore=rows.filter(r=>r.restored_byte_identical!==1);console.log(JSON.stringify({total:rows.length,killed:kills,survived:surv,status_ok:ok,unexpected:unexpected.map(r=>r.id),restore_failures:badrestore.map(r=>r.id)},null,2))'
