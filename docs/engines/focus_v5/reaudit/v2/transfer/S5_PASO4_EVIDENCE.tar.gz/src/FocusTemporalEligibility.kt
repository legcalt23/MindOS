package com.mindos.app.features.mindboost.focus2.domain.evidence

import com.mindos.app.features.mindboost.core.timing.ClockDomain
import com.mindos.app.features.mindboost.core.timing.ProbeCapability
import com.mindos.app.features.mindboost.core.timing.TemporalClass
import com.mindos.app.features.mindboost.core.timing.TemporalClassPolicy
import com.mindos.app.features.mindboost.core.timing.TemporalQualityThresholds
import com.mindos.app.features.mindboost.core.timing.TemporalWindowBucket
import com.mindos.app.features.mindboost.core.timing.WindowExclusionReason
import com.mindos.app.features.mindboost.focus2.domain.runtime.FocusRuntimeSnapshot

/**
 * S5 · ADR-FOCUS-TEMPORAL-QUALITY §9 — SHADOW derivation of a session's temporal eligibility from
 * the stratified cells. Pure, versioned by [TemporalQualityThresholds.version], and UNMOUNTED: no
 * production call-site alters any official verdict with this in S5 (Paso 4 wires the candidate).
 *
 * The load-bearing third verdict is [Verdict.NotCaptured]: a v1 record (or a probe-less session)
 * has EMPTY cells, and reading that as "0 bad windows" would fabricate a maximum while reading it
 * as "0 good ones" would fabricate a minimum. Absence is its own typed state, mirroring
 * `Descriptive.Absent`/`Verdict.InsufficientData` on the accuracy axis.
 */
object FocusTemporalEligibility {

    /** Session-level verdict for the SHADOW RT lane. */
    sealed interface Verdict {
        data object Eligible : Verdict

        /** Reserved for Paso 4's window-level SE-inflation tier (alt 6); never produced in P3. */
        data object Degraded : Verdict

        data class Excluded(val causes: Set<ExclusionCause>) : Verdict
        data object NotCaptured : Verdict
    }

    enum class ExclusionCause { NON_AUTHORITATIVE_CLASS, COVERAGE_INCOMPLETE, SESSION_BACKSTOP_EXCEEDED }

    /** Everything the shadow candidate needs, derived — never persisted (single authority = cells). */
    data class TemporalEvaluation(
        val sessionClass: TemporalClass,
        val windowsClassified: Int,
        val coverageComplete: Boolean,
        /** (resolved-excluded + attributed discards) / (classified + discards); null = nothing classified. */
        val excludedFraction: Double?,
        val rtShadowVerdict: Verdict,
    )

    fun evaluate(
        probeCapability: ProbeCapability?,
        clockDomain: ClockDomain,
        snapshot: FocusRuntimeSnapshot,
        thresholds: TemporalQualityThresholds = TemporalQualityThresholds.DEFAULT,
    ): TemporalEvaluation {
        val cells = snapshot.temporalCells
        if (probeCapability == null || cells.isEmpty()) {
            return TemporalEvaluation(
                sessionClass = TemporalClass.T0_NON_AUTHORITATIVE,
                windowsClassified = 0,
                coverageComplete = false,
                excludedFraction = null,
                rtShadowVerdict = Verdict.NotCaptured,
            )
        }
        val sessionClass = TemporalClassPolicy.sessionClass(
            capability = probeCapability,
            clockDomain = clockDomain,
            sampledFramesSession = snapshot.temporalSampledFrames,
            thresholds = thresholds,
        )
        val windowsClassified = cells.sumOf { it.cell.totalTrials }
        val excludedResolved = cells
            .filter { it.bucket == TemporalWindowBucket.EXCLUDED }
            .sumOf { it.cell.totalTrials }
        val discardReasons = setOf(
            WindowExclusionReason.PAUSE_DISCARD.name,
            WindowExclusionReason.CLOCK_EPOCH.name,
        )
        val discards = cells.sumOf { cell ->
            cell.excludedByReason.filterKeys { it in discardReasons }.values.sum()
        }
        val denominator = windowsClassified + discards
        val excludedFraction =
            if (denominator > 0) (excludedResolved + discards).toDouble() / denominator else null
        val coverageComplete = windowsClassified == snapshot.resolvedTrials
        val causes = buildSet {
            if (sessionClass != TemporalClass.T1_FRAME_OBSERVED) add(ExclusionCause.NON_AUTHORITATIVE_CLASS)
            if (!coverageComplete) add(ExclusionCause.COVERAGE_INCOMPLETE)
            if ((excludedFraction ?: FULLY_EXCLUDED) > thresholds.sessionExcludedMax) {
                add(ExclusionCause.SESSION_BACKSTOP_EXCEEDED)
            }
        }
        return TemporalEvaluation(
            sessionClass = sessionClass,
            windowsClassified = windowsClassified,
            coverageComplete = coverageComplete,
            excludedFraction = excludedFraction,
            rtShadowVerdict = if (causes.isEmpty()) Verdict.Eligible else Verdict.Excluded(causes),
        )
    }

    /** An underivable fraction can never pass a "below ceiling" check (fail-closed, not a fake 0.0). */
    private const val FULLY_EXCLUDED: Double = 1.0
}
